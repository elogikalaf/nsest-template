module.exports = {
  types: [
    { value: "feat", name: "feat:     A new feature" },
    { value: "fix", name: "fix:      A bug fix" },
    // Add other commit types as needed
  ],
  // Your other configurations...
};
